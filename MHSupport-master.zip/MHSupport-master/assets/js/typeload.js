$(document).ready(() => {
    $("span.typed").typed({
        strings: ["Answers now", "MHSupport"],
        typeSpeed: 50,
        backSpeed: 30,
        backDelay: 700,
        loop: true
    });

});
